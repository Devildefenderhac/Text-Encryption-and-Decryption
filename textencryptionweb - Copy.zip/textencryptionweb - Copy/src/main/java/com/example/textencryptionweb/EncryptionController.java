package com.example.textencryptionweb;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.*;
import java.util.Base64;

@Controller
public class EncryptionController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/encrypt")
    public String encrypt(
            @RequestParam String text,
            @RequestParam String algorithm,
            Model model) throws Exception {

        String encrypted = "";
        String decrypted = "";

        if (algorithm.equals("AES")) {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(128);
            SecretKey secretKey = keyGen.generateKey();
            Cipher cipher = Cipher.getInstance("AES");

            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(text.getBytes());
            encrypted = Base64.getEncoder().encodeToString(encryptedBytes);

            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            decrypted = new String(decryptedBytes);

        } else if (algorithm.equals("DES")) {
            KeyGenerator keyGen = KeyGenerator.getInstance("DES");
            SecretKey secretKey = keyGen.generateKey();
            Cipher cipher = Cipher.getInstance("DES");

            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            byte[] encryptedBytes = cipher.doFinal(text.getBytes());
            encrypted = Base64.getEncoder().encodeToString(encryptedBytes);

            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            decrypted = new String(decryptedBytes);

        } else if (algorithm.equals("RSA")) {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(2048);
            KeyPair pair = keyGen.generateKeyPair();

            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, pair.getPublic());
            byte[] encryptedBytes = cipher.doFinal(text.getBytes());
            encrypted = Base64.getEncoder().encodeToString(encryptedBytes);

            cipher.init(Cipher.DECRYPT_MODE, pair.getPrivate());
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            decrypted = new String(decryptedBytes);
        }

        model.addAttribute("text", text);
        model.addAttribute("algorithm", algorithm);
        model.addAttribute("encrypted", encrypted);
        model.addAttribute("decrypted", decrypted);
        return "index";
    }
}
