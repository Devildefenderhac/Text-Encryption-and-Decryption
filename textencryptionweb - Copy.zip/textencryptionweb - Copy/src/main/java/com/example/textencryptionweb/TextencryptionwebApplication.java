package com.example.textencryptionweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextencryptionwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(TextencryptionwebApplication.class, args);
	}

}
